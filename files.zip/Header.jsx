// src/components/Header.jsx
export default function Header({ dnd, setDnd }) {
  return (
    <header className="header">
      <div className="header-logo">
        <div className="header-logo-icon">📚</div>
        <h1>Study<span>AI</span></h1>
      </div>

      <button
        className={`dnd-btn ${dnd ? "dnd-btn--on" : ""}`}
        onClick={() => setDnd(v => !v)}
        title="Toggle Do Not Disturb focus mode"
      >
        {dnd ? "🔕 DND On" : "🔔 Focus Mode"}
      </button>
    </header>
  );
}
