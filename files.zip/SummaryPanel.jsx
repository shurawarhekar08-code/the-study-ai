// src/components/SummaryPanel.jsx
// ─────────────────────────────────────────────────────────────
// Standalone text summarizer — calls POST /summarize
// ─────────────────────────────────────────────────────────────
import { useState } from "react";
import api from "../api.js";
import "./SummaryPanel.css";

export default function SummaryPanel() {
  const [text,    setText]    = useState("");
  const [summary, setSummary] = useState("");
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState("");

  async function handleSummarize() {
    if (!text.trim() || loading) return;
    setLoading(true);
    setError("");
    setSummary("");

    try {
      const { data } = await api.post("/summarize", { text });
      setSummary(data.summary);
    } catch (err) {
      setError(err.response?.data?.error || "⚠️ Backend unreachable. Is Flask running?");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="panel">
      <div className="panel-header">
        <span className="panel-icon">📝</span>
        <h2>Notes Summarizer</h2>
      </div>

      <div className="sum-body">
        <textarea
          className="field"
          value={text}
          onChange={e => setText(e.target.value)}
          placeholder="Paste your long notes, article, or textbook passage here (min ~30 words)…"
          style={{ minHeight: 100 }}
        />

        <button
          className="btn-primary"
          onClick={handleSummarize}
          disabled={loading || !text.trim()}
        >
          {loading ? <><span className="spin" /> Summarizing…</> : "✨ Summarize"}
        </button>

        {error   && <p className="error-msg">{error}</p>}

        {summary && (
          <div className="sum-result fade-in">
            <p className="sum-result-label">Summary</p>
            <p>{summary}</p>
          </div>
        )}
      </div>
    </div>
  );
}
