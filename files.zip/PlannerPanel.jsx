// src/components/PlannerPanel.jsx
// ─────────────────────────────────────────────────────────────
// Weekly study planner — calls POST /planner
// Falls back to client-side generation if backend is unreachable
// ─────────────────────────────────────────────────────────────
import { useState } from "react";
import api from "../api.js";
import "./PlannerPanel.css";

const DAYS = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"];
const TIPS  = {
  math:      "Practice ≥5 problems per session.",
  science:   "Draw diagrams to visualise concepts.",
  history:   "Build a timeline of key events.",
  english:   "Read & summarise one article.",
  biology:   "Use flashcards for terminology.",
  physics:   "Solve numericals step-by-step.",
  chemistry: "Balance equations aloud.",
  geography: "Study maps alongside notes.",
  computer:  "Code along — don't just read.",
  economics: "Link theory to real-world examples.",
};

function getTip(s) {
  const k = Object.keys(TIPS).find(k => s.toLowerCase().includes(k));
  return TIPS[k] || "Review last session's notes before starting.";
}

// Client-side fallback plan generator
function buildPlanLocally(subjects, hoursPerDay) {
  const plan = {};
  const total = hoursPerDay * 7;
  const cycle = Array.from({ length: Math.ceil(total / subjects.length) }, () => subjects).flat().slice(0, total);
  let slot = 0;
  for (const day of DAYS) {
    plan[day] = [];
    for (let i = 0; i < hoursPerDay; i++) {
      const subj = cycle[slot++];
      plan[day].push({ subject: subj, duration: "1 hour", tip: getTip(subj) });
    }
  }
  return plan;
}

export default function PlannerPanel() {
  const [subjectsRaw, setSubjectsRaw] = useState("");
  const [hours,       setHours]       = useState(2);
  const [plan,        setPlan]        = useState(null);
  const [loading,     setLoading]     = useState(false);
  const [error,       setError]       = useState("");

  async function handleGenerate() {
    const subjects = subjectsRaw.split(",").map(s => s.trim()).filter(Boolean);
    if (!subjects.length) { setError("Enter at least one subject."); return; }
    const hrs = Math.min(8, Math.max(1, Number(hours) || 2));

    setLoading(true);
    setError("");
    setPlan(null);

    try {
      const { data } = await api.post("/planner", { subjects, hours_per_day: hrs });
      setPlan(data.plan);
    } catch {
      // Backend unreachable → generate locally so the UI still works
      setPlan(buildPlanLocally(subjects, hrs));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="panel">
      <div className="panel-header">
        <span className="panel-icon">📅</span>
        <h2>Study Planner</h2>
      </div>

      <div className="plan-body">
        <input
          className="field"
          type="text"
          value={subjectsRaw}
          onChange={e => setSubjectsRaw(e.target.value)}
          placeholder="Subjects (comma-separated): Math, Biology, English"
        />

        <div className="plan-row">
          <label className="plan-label">Hours / day</label>
          <input
            className="field plan-hours"
            type="number"
            value={hours}
            onChange={e => setHours(e.target.value)}
            min={1} max={8}
          />
        </div>

        <button
          className="btn-primary"
          onClick={handleGenerate}
          disabled={loading || !subjectsRaw.trim()}
        >
          {loading ? <><span className="spin" /> Generating…</> : "📅 Generate Plan"}
        </button>

        {error && <p className="error-msg">{error}</p>}

        {plan && (
          <div className="week fade-in">
            {DAYS.map(day => (
              <div key={day} className="pday">
                <div className="pday-header">{day}</div>
                {(plan[day] || []).map((s, i) => (
                  <div key={i} className="psession">
                    <span className="psession-subj">{s.subject}</span>
                    <div>
                      <div className="psession-meta">⏱ {s.duration}</div>
                      <div className="psession-tip">💡 {s.tip}</div>
                    </div>
                  </div>
                ))}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
