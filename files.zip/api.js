// src/api.js
// ─────────────────────────────────────────────────────────────
// Single place to configure the backend URL.
// Reads VITE_API_URL from .env (or .env.production on Vercel).
// Falls back to localhost for local development.
// ─────────────────────────────────────────────────────────────
import axios from "axios";

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "http://localhost:5000",
  headers: { "Content-Type": "application/json" },
  timeout: 60_000, // 60 s — models can be slow on first call
});

export default api;
