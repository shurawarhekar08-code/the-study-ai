// src/App.jsx — Root component
// Composes Header + three-column dashboard layout
import { useState } from "react";
import Header    from "./components/Header.jsx";
import ChatPanel from "./components/ChatPanel.jsx";
import SummaryPanel from "./components/SummaryPanel.jsx";
import PlannerPanel from "./components/PlannerPanel.jsx";
import TodoPanel    from "./components/TodoPanel.jsx";
import "./App.css";

export default function App() {
  const [dnd, setDnd]           = useState(false);
  const [activeTab, setActiveTab] = useState("chat"); // mobile tabs

  return (
    <div className={`shell ${dnd ? "dnd" : ""}`}>
      <Header dnd={dnd} setDnd={setDnd} />

      {dnd && (
        <div className="dnd-banner">
          🔕 DO NOT DISTURB — Focus Mode Active
        </div>
      )}

      {/* Mobile tab navigation */}
      <nav className="tabbar">
        {[
          { id: "chat",      label: "💬 Chat"      },
          { id: "summarize", label: "📝 Summarize"  },
          { id: "planner",   label: "📅 Planner"    },
          { id: "todo",      label: "✅ To-Do"      },
        ].map(({ id, label }) => (
          <button
            key={id}
            className={`tab ${activeTab === id ? "tab--active" : ""}`}
            onClick={() => setActiveTab(id)}
          >
            {label}
          </button>
        ))}
      </nav>

      {/* Dashboard */}
      <main className="dashboard">
        {/* Left: Chat */}
        <section className={`col col-chat ${activeTab === "chat" ? "col--show" : ""}`}>
          <ChatPanel />
        </section>

        {/* Right: side panels */}
        <aside className="col col-side">
          <div className={activeTab === "summarize" ? "col--show" : ""}>
            <SummaryPanel />
          </div>
          <div className={activeTab === "planner" ? "col--show" : ""}>
            <PlannerPanel />
          </div>
          <div className={activeTab === "todo" ? "col--show" : ""}>
            <TodoPanel />
          </div>
        </aside>
      </main>
    </div>
  );
}
