# ==============================================================
#  ai_pipeline.py  —  HuggingFace Transformer Pipelines
# ==============================================================
#  Models used:
#    Summarization    : facebook/bart-large-cnn   (~1.6 GB)
#    Question-Answering: deepset/roberta-base-squad2 (~500 MB)
#
#  Both models are downloaded automatically from HuggingFace Hub
#  on the FIRST run, then cached in ~/.cache/huggingface/
#
#  💡 Tip: On Render's free tier the first cold-start may take
#  a few minutes while models are downloaded. After that
#  responses are fast.
# ==============================================================

from transformers import pipeline

print("⏳  Loading AI models — first run downloads ~2 GB, please wait…")

# ── Summarization pipeline ────────────────────────────────────
# Great for condensing long notes into key points.
summarizer = pipeline(
    "summarization",
    model="facebook/bart-large-cnn",
    # device=0,  # ← Uncomment if you have a CUDA GPU
)

# ── Question-Answering pipeline ───────────────────────────────
# Extracts the best answer to a question from a given passage.
qa_model = pipeline(
    "question-answering",
    model="deepset/roberta-base-squad2",
)

print("✅  AI models ready!")


def get_summary(text: str) -> str:
    """
    Summarizes the given text.

    Args:
        text: Long text (article, notes, etc.)
    Returns:
        A concise summary string.
    """
    words     = text.split()
    word_count = len(words)

    # Dynamically size the output based on input length
    max_len = min(150, max(40, word_count // 3))
    min_len = max(20, max_len - 30)

    try:
        result = summarizer(text, max_length=max_len, min_length=min_len, do_sample=False)
        return result[0]["summary_text"]
    except Exception as exc:
        return f"⚠️ Summarization error: {exc}"


def get_answer(question: str, context: str) -> str:
    """
    Extracts an answer to a question from the provided context.

    Args:
        question: The student's question.
        context:  The study material / passage to search.
    Returns:
        The extracted answer string.
    """
    try:
        result = qa_model(question=question, context=context)
        score  = result.get("score", 0)

        if score < 0.10:
            return (
                "I couldn't find a confident answer in your notes. "
                "Try rephrasing your question or adding more relevant context."
            )

        return result["answer"]
    except Exception as exc:
        return f"⚠️ Q&A error: {exc}"
