// src/components/TodoPanel.jsx
// ─────────────────────────────────────────────────────────────
// Client-side To-Do list — no backend needed
// Features: add, complete (toggle), delete
// ─────────────────────────────────────────────────────────────
import { useState } from "react";
import "./TodoPanel.css";

const SEED = [
  { id: 1, text: "Review Chapter 3 notes",    done: false },
  { id: 2, text: "Solve 10 math problems",    done: false },
];

export default function TodoPanel() {
  const [todos,   setTodos]  = useState(SEED);
  const [newText, setNew]    = useState("");

  function add() {
    const t = newText.trim();
    if (!t) return;
    setTodos(prev => [...prev, { id: Date.now(), text: t, done: false }]);
    setNew("");
  }

  function toggle(id) {
    setTodos(prev => prev.map(t => t.id === id ? { ...t, done: !t.done } : t));
  }

  function remove(id) {
    setTodos(prev => prev.filter(t => t.id !== id));
  }

  const doneCount = todos.filter(t => t.done).length;

  return (
    <div className="panel">
      <div className="panel-header">
        <span className="panel-icon">✅</span>
        <h2>To-Do List</h2>
      </div>

      <div className="todo-body">
        {/* Add row */}
        <div className="todo-add">
          <input
            className="field"
            type="text"
            value={newText}
            onChange={e => setNew(e.target.value)}
            onKeyDown={e => e.key === "Enter" && add()}
            placeholder="Add a study task…"
          />
          <button className="btn-add" onClick={add} title="Add task">+</button>
        </div>

        {/* Stats */}
        {todos.length > 0 && (
          <div className="todo-stats">
            <span className="ts-done">✓ {doneCount} done</span>
            <span className="ts-sep">/</span>
            <span className="ts-total">{todos.length} total</span>
          </div>
        )}

        {/* List */}
        <div className="todo-list">
          {todos.length === 0 && (
            <p className="todo-empty">No tasks yet — add one above! 🎯</p>
          )}

          {todos.map(t => (
            <div key={t.id} className={`todo-item ${t.done ? "todo-item--done" : ""}`}>
              <button
                className="todo-check"
                onClick={() => toggle(t.id)}
                title={t.done ? "Mark incomplete" : "Mark complete"}
              >
                {t.done && "✓"}
              </button>
              <span className="todo-text">{t.text}</span>
              <button
                className="todo-del"
                onClick={() => remove(t.id)}
                title="Delete"
              >✕</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
