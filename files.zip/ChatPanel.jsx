// src/components/ChatPanel.jsx
// ─────────────────────────────────────────────────────────────
// Main chatbot panel.
// • "summarize" in message  → POST /chat (summarization model)
// • Any other question      → POST /chat (QA model, needs context)
// ─────────────────────────────────────────────────────────────
import { useState, useRef, useEffect } from "react";
import api from "../api.js";
import "./ChatPanel.css";

const WELCOME = {
  id:   0,
  role: "bot",
  text: `👋 Hi! I'm your AI Study Assistant.\n\nHere's what I can do:\n• Type "summarize ..." to condense any text\n• Ask a question — paste your notes in the Context box first\n• Use the right panels for Planner & To-Do\n\nWhat are you studying today?`,
};

export default function ChatPanel() {
  const [messages, setMessages] = useState([WELCOME]);
  const [input,    setInput]    = useState("");
  const [context,  setContext]  = useState("");
  const [loading,  setLoading]  = useState(false);
  const bottomRef               = useRef(null);

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  // ── Send ───────────────────────────────────────────────────
  async function sendMessage() {
    const text = input.trim();
    if (!text || loading) return;

    setMessages(prev => [...prev, { id: Date.now(), role: "user", text }]);
    setInput("");
    setLoading(true);

    try {
      const { data } = await api.post("/chat", { message: text, context });
      setMessages(prev => [...prev, { id: Date.now() + 1, role: "bot", text: data.reply }]);
    } catch {
      setMessages(prev => [
        ...prev,
        {
          id:   Date.now() + 1,
          role: "bot",
          text: "⚠️ Cannot reach the backend.\n\nMake sure Flask is running on port 5000 (local) or check your Render URL in .env.",
        },
      ]);
    } finally {
      setLoading(false);
    }
  }

  function handleKey(e) {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  }

  return (
    <div className="chat-wrap">
      <div className="panel-header">
        <span className="panel-icon">💬</span>
        <h2>AI Chat Assistant</h2>
      </div>

      {/* Messages */}
      <div className="chat-messages">
        {messages.map(msg => (
          <div key={msg.id} className={`msg msg--${msg.role}`}>
            <span className="msg-label">{msg.role === "user" ? "You" : "StudyAI"}</span>
            <div className="msg-bubble">{msg.text}</div>
          </div>
        ))}

        {loading && (
          <div className="msg msg--bot">
            <span className="msg-label">StudyAI</span>
            <div className="typing">
              <span /><span /><span />
            </div>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Context textarea */}
      <div className="ctx-box">
        <p className="ctx-label">📄 Context — paste study material for Q&amp;A</p>
        <textarea
          className="field"
          value={context}
          onChange={e => setContext(e.target.value)}
          placeholder="Paste notes or textbook text here so I can answer questions about it…"
          style={{ minHeight: 60, maxHeight: 120 }}
        />
      </div>

      {/* Input bar */}
      <div className="chat-bar">
        <input
          className="chat-input"
          type="text"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={handleKey}
          placeholder='Ask a question or type "summarize ..." '
          disabled={loading}
        />
        <button
          className="send-btn"
          onClick={sendMessage}
          disabled={loading || !input.trim()}
          title="Send"
        >
          ➤
        </button>
      </div>
    </div>
  );
}
